# E-commerce teaching API

This is the repaired FastAPI/SQLite project. The original generated files and failed test runs remain in DevSphere's version history. The repair and its regression tests were reviewed and written during maintenance, not presented as an autonomous model output.

## Run on your computer

1. Install Python 3.12 and create a virtual environment: `python -m venv .venv`.
2. Activate it: `source .venv/bin/activate` on macOS/Linux, or `.venv\Scripts\activate` on Windows.
3. Run `pip install -r requirements.txt`.
4. Set `JWT_SECRET` to your own random secret. `DATABASE_FILE` optionally selects a writable SQLite path; it defaults to `ecommerce.db`. If no JWT secret is configured, an ephemeral random secret is generated and tokens stop working after a restart.
5. Start with `uvicorn app:app --host 127.0.0.1 --port 8000` and open `http://localhost:8000/docs`.
6. Register at `POST /api/users`, then submit JSON email/password to `POST /api/users/login`. Use the returned token as `Authorization: Bearer <token>`.
7. Administrators can add products; normal users can browse, add/remove cart items, create orders and view their own history. Registration never grants administrator privileges. A trusted administrator must provision that role directly in the local database; tests provision it through an isolated database fixture.
8. `POST /api/test-payment` only simulates a status change. It never contacts a payment provider or charges money.
9. After reviewing the source, run `python -m pytest tests -q` in an isolated development environment. DevSphere executes these tests only inside its constrained Docker sandbox.

## Tests

The regression suite covers registration, stored password hashes, validation, login, malformed tokens, admin-only product creation, cart operations, stock checks, atomic checkout, cross-user access, history, empty carts, and test-payment ownership/replay/validation. Each test uses a separate temporary database. Test results come from actual execution; see DevSphere's Testing tab for the recorded run and source hash.

## Limits

This project is a local college API demonstration, not a production storefront. It has no frontend yet, external payment integration, password-reset flow, payment reservation/refund lifecycle, production rate limits or scalability benchmark. Prices use rounded floating-point arithmetic; a production system should use integer minor units or decimal accounting. The stock reservation remains consumed if a simulated payment fails. Review and harden these policies before any real deployment.
