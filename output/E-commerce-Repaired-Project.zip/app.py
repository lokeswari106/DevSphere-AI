"""Human-reviewed repair of the generated college demonstration API.

Payments are a local simulation; no provider is contacted and no money is charged.
"""
import os
import re
import secrets
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Literal

import bcrypt
from fastapi import Depends, FastAPI, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from pydantic import BaseModel, ConfigDict, Field, field_validator

app = FastAPI(title="E-commerce teaching API")
DB_PATH = os.getenv("DATABASE_FILE", "ecommerce.db")
# For a persistent deployment set JWT_SECRET; the default is deliberately ephemeral.
JWT_SECRET = os.getenv("JWT_SECRET") or secrets.token_urlsafe(48)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/users/login")
SCHEMA = '''
CREATE TABLE IF NOT EXISTS User (id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, is_admin INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS Product (id TEXT PRIMARY KEY, name TEXT NOT NULL, price REAL NOT NULL CHECK(price>0), stock INTEGER NOT NULL CHECK(stock>=0));
CREATE TABLE IF NOT EXISTS Cart (id TEXT PRIMARY KEY, user_id TEXT UNIQUE NOT NULL REFERENCES User(id));
CREATE TABLE IF NOT EXISTS CartItem (id TEXT PRIMARY KEY, cart_id TEXT NOT NULL REFERENCES Cart(id), product_id TEXT NOT NULL REFERENCES Product(id), quantity INTEGER NOT NULL CHECK(quantity>0), UNIQUE(cart_id, product_id));
CREATE TABLE IF NOT EXISTS "Order" (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES User(id), total REAL NOT NULL, payment_status TEXT NOT NULL DEFAULT 'pending');
CREATE TABLE IF NOT EXISTS OrderItem (id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES "Order"(id), product_id TEXT NOT NULL REFERENCES Product(id), quantity INTEGER NOT NULL, price REAL NOT NULL);
'''


@contextmanager
def database():
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.executescript(SCHEMA)
    try:
        with connection:
            yield connection
    finally:
        connection.close()


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid")


class UserCreate(Input):
    email: str = Field(max_length=254)
    password: str = Field(min_length=8, max_length=72)
    is_admin: Literal[False] = False

    @field_validator("email")
    @classmethod
    def valid_email(cls, value):
        value = value.strip().lower()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
            raise ValueError("Enter a valid email address")
        return value

    @field_validator("password")
    @classmethod
    def valid_password(cls, value):
        if len(value.encode()) > 72:
            raise ValueError("Password must be at most 72 UTF-8 bytes")
        return value


class UserLogin(Input):
    email: str
    password: str


class ProductCreate(Input):
    name: str = Field(min_length=1, max_length=150)
    price: float = Field(gt=0, allow_inf_nan=False)
    stock: int = Field(ge=0, strict=True)


class CartItemCreate(Input):
    product_id: str
    quantity: int = Field(gt=0, le=10000, strict=True)


class OrderCreate(Input):
    cart_id: str


class PaymentStatusUpdate(Input):
    order_id: str
    payment_status: Literal["success", "failed"]


def create_token(user_id):
    return jwt.encode({"sub": user_id, "exp": datetime.now(timezone.utc) + timedelta(hours=1)}, JWT_SECRET, algorithm="HS256")


def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"], options={"require_exp": True, "require_sub": True})
        with database() as db:
            user = db.execute("SELECT * FROM User WHERE id=?", (payload["sub"],)).fetchone()
        if not user:
            raise ValueError("Unknown user")
        return dict(user)
    except (JWTError, KeyError, ValueError):
        raise HTTPException(401, "Invalid or expired token", headers={"WWW-Authenticate": "Bearer"})


def cart_for(db, user_id):
    cart = db.execute("SELECT * FROM Cart WHERE user_id=?", (user_id,)).fetchone()
    if not cart:
        db.execute("INSERT INTO Cart(id,user_id) VALUES (?,?)", (str(uuid.uuid4()), user_id))
        cart = db.execute("SELECT * FROM Cart WHERE user_id=?", (user_id,)).fetchone()
    return dict(cart)


def cart_items(db, cart_id):
    return [dict(r) for r in db.execute("SELECT c.*,p.price,p.stock FROM CartItem c JOIN Product p ON c.product_id=p.id WHERE c.cart_id=?", (cart_id,))]


@app.post("/api/users", status_code=201)
def create_user(user: UserCreate):
    uid = str(uuid.uuid4())
    password_hash = bcrypt.hashpw(user.password.encode(), bcrypt.gensalt()).decode()
    try:
        with database() as db:
            db.execute("INSERT INTO User(id,email,password_hash,is_admin) VALUES (?,?,?,0)", (uid, user.email, password_hash))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Email already registered")
    return {"id": uid, "email": user.email}


@app.post("/api/users/login")
def login_user(user: UserLogin):
    with database() as db:
        record = db.execute("SELECT * FROM User WHERE email=?", (user.email.strip().lower(),)).fetchone()
    valid = False
    if record and len(user.password.encode()) <= 72:
        valid = bcrypt.checkpw(user.password.encode(), record["password_hash"].encode())
    if not valid:
        raise HTTPException(401, "Invalid credentials")
    return {"id": record["id"], "email": record["email"], "is_admin": bool(record["is_admin"]), "token": create_token(record["id"])}


@app.get("/api/products")
def get_products():
    with database() as db:
        return [dict(row) for row in db.execute("SELECT * FROM Product")]


@app.post("/api/products", status_code=201)
def create_product(product: ProductCreate, user=Depends(get_current_user)):
    if not user["is_admin"]:
        raise HTTPException(403, "Admin access required")
    data = {"id": str(uuid.uuid4()), **product.model_dump()}
    with database() as db:
        db.execute("INSERT INTO Product(id,name,price,stock) VALUES (?,?,?,?)", tuple(data.values()))
    return data


@app.get("/api/cart")
def get_cart(user_id: str | None = None, user=Depends(get_current_user)):
    if user_id is not None and user_id != user["id"]:
        raise HTTPException(403, "Access denied")
    with database() as db:
        db.execute("BEGIN IMMEDIATE")
        cart = cart_for(db, user["id"])
        return {**cart, "items": cart_items(db, cart["id"])}


@app.post("/api/cart", status_code=201)
def add_to_cart(item: CartItemCreate, user=Depends(get_current_user)):
    with database() as db:
        db.execute("BEGIN IMMEDIATE")
        product = db.execute("SELECT * FROM Product WHERE id=?", (item.product_id,)).fetchone()
        if not product:
            raise HTTPException(404, "Product not found")
        cart = cart_for(db, user["id"])
        old = db.execute("SELECT * FROM CartItem WHERE cart_id=? AND product_id=?", (cart["id"], item.product_id)).fetchone()
        quantity = item.quantity + (old["quantity"] if old else 0)
        if quantity > product["stock"]:
            raise HTTPException(409, "Insufficient stock")
        ident = old["id"] if old else str(uuid.uuid4())
        db.execute("INSERT INTO CartItem(id,cart_id,product_id,quantity) VALUES (?,?,?,?) ON CONFLICT(cart_id,product_id) DO UPDATE SET quantity=excluded.quantity", (ident, cart["id"], item.product_id, quantity))
        return {"id": ident, "cart_id": cart["id"], "product_id": item.product_id, "quantity": quantity, "price": product["price"]}


@app.delete("/api/cart")
def remove_from_cart(item: CartItemCreate, user=Depends(get_current_user)):
    with database() as db:
        cart = db.execute("SELECT * FROM Cart WHERE user_id=?", (user["id"],)).fetchone()
        if not cart:
            raise HTTPException(404, "Cart not found")
        cursor = db.execute("DELETE FROM CartItem WHERE cart_id=? AND product_id=?", (cart["id"], item.product_id))
        if cursor.rowcount != 1:
            raise HTTPException(404, "Item not found")
    return {"detail": "Item removed from cart"}


@app.post("/api/orders", status_code=201)
def place_order(order: OrderCreate, user=Depends(get_current_user)):
    with database() as db:
        db.execute("BEGIN IMMEDIATE")
        cart = db.execute("SELECT * FROM Cart WHERE id=? AND user_id=?", (order.cart_id, user["id"])).fetchone()
        if not cart:
            raise HTTPException(404, "Cart not found")
        items = cart_items(db, cart["id"])
        if not items:
            raise HTTPException(400, "Cart is empty")
        total = round(sum(i["price"] * i["quantity"] for i in items), 2)
        oid = str(uuid.uuid4())
        db.execute('INSERT INTO "Order"(id,user_id,total,payment_status) VALUES (?,?,?,?)', (oid, user["id"], total, "pending"))
        for item in items:
            changed = db.execute("UPDATE Product SET stock=stock-? WHERE id=? AND stock>=?", (item["quantity"], item["product_id"], item["quantity"]))
            if changed.rowcount != 1:
                raise HTTPException(409, "Insufficient stock")
            db.execute("INSERT INTO OrderItem(id,order_id,product_id,quantity,price) VALUES (?,?,?,?,?)", (str(uuid.uuid4()), oid, item["product_id"], item["quantity"], item["price"]))
        db.execute("DELETE FROM CartItem WHERE cart_id=?", (cart["id"],))
    return {"id": oid, "user_id": user["id"], "total": total, "payment_status": "pending"}


@app.get("/api/orders")
def get_orders(user_id: str | None = None, user=Depends(get_current_user)):
    if user_id is not None and user_id != user["id"]:
        raise HTTPException(403, "Access denied")
    with database() as db:
        return [dict(r) for r in db.execute('SELECT * FROM "Order" WHERE user_id=?', (user["id"],))]


@app.post("/api/test-payment")
def process_test_payment(payment: PaymentStatusUpdate, user=Depends(get_current_user)):
    try:
        uuid.UUID(payment.order_id)
    except ValueError:
        raise HTTPException(400, "Invalid order ID format")
    with database() as db:
        db.execute("BEGIN IMMEDIATE")
        order = db.execute('SELECT * FROM "Order" WHERE id=?', (payment.order_id,)).fetchone()
        if not order:
            raise HTTPException(404, "Order not found")
        if order["user_id"] != user["id"]:
            raise HTTPException(403, "Access denied")
        if order["payment_status"] != "pending":
            raise HTTPException(400, "Payment already processed")
        db.execute('UPDATE "Order" SET payment_status=? WHERE id=?', (payment.payment_status, payment.order_id))
    return {"order_id": payment.order_id, "payment_status": payment.payment_status, "test_mode": True, "message": "Simulated payment recorded; no money was charged"}
