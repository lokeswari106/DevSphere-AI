# Database


## Summary

Database and API Design for E-commerce Platform


## Entities

- {"keys": ["id"], "name": "User", "fields": ["UUID id PK", "string email", "string password_hash", "UUID cart_id", "List<Order> orders"], "indexes": ["email"]}

- {"keys": ["id"], "name": "Product", "fields": ["UUID id PK", "string name", "float price", "int stock"], "indexes": ["name"]}

- {"keys": ["id"], "name": "Cart", "fields": ["UUID id PK", "UUID user_id", "List<CartItem> items"], "indexes": ["user_id"]}

- {"keys": ["id"], "name": "CartItem", "fields": ["UUID id PK", "UUID product_id", "int quantity"], "indexes": ["product_id"]}

- {"keys": ["id"], "name": "Order", "fields": ["UUID id PK", "UUID user_id", "List<OrderItem> products", "float total", "string payment_status"], "indexes": ["user_id"]}

- {"keys": ["id"], "name": "OrderItem", "fields": ["UUID id PK", "UUID product_id", "int quantity", "float price"], "indexes": ["product_id"]}


## Er Diagram

erDiagram
  User ||--o{ Order : "has"
  User ||--o{ Cart : "owns"
  Product ||--o{ CartItem : "in"
  Order ||--o{ OrderItem : "contains"
  Cart ||--o{ CartItem : "contains"
  Order ||--o{ Payment : "has"

  User {
    UUID id PK
    string email
    string password_hash
    UUID cart_id
    List<Order> orders
  }

  Product {
    UUID id PK
    string name
    float price
    int stock
  }

  Cart {
    UUID id PK
    UUID user_id
    List<CartItem> items
  }

  CartItem {
    UUID id PK
    UUID product_id
    int quantity
  }

  Order {
    UUID id PK
    UUID user_id
    List<OrderItem> products
    float total
    string payment_status
  }

  OrderItem {
    UUID id PK
    UUID product_id
    int quantity
    float price
  }


## Openapi Json

{
  "openapi": "3.0.3",
  "info": {
    "title": "Generated project API",
    "version": "1.0.0"
  },
  "paths": {
    "/api/users": {
      "post": {
        "summary": "Register a new user",
        "responses": {
          "201": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "id": {
                      "type": "string",
                      "description": "User's unique ID"
                    },
                    "email": {
                      "type": "string",
                      "description": "User's email address"
                    }
                  },
                  "required": [
                    "id",
                    "email"
                  ]
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        },
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "email": {
                    "type": "string",
                    "description": "User's email address"
                  },
                  "password": {
                    "type": "string",
                    "description": "User's password"
                  }
                },
                "required": [
                  "email",
                  "password"
                ]
              }
            }
          }
        }
      }
    },
    "/api/users/login": {
      "post": {
        "summary": "Login to the system",
        "responses": {
          "200": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "id": {
                      "type": "string",
                      "description": "User's unique ID"
                    },
                    "email": {
                      "type": "string",
                      "description": "User's email address"
                    }
                  },
                  "required": [
                    "id",
                    "email"
                  ]
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        },
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "email": {
                    "type": "string",
                    "description": "User's email address"
                  },
                  "password": {
                    "type": "string",
                    "description": "User's password"
                  }
                },
                "required": [
                  "email",
                  "password"
                ]
              }
            }
          }
        }
      }
    },
    "/api/products": {
      "get": {
        "summary": "Get all products",
        "responses": {
          "200": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "array",
                  "items": {
                    "type": "object",
                    "properties": {
                      "id": {
                        "type": "string",
                        "description": "Product's unique ID"
                      },
                      "name": {
                        "type": "string",
                        "description": "Product's name"
                      },
                      "price": {
                        "type": "number",
                        "description": "Product's price"
                      },
                      "stock": {
                        "type": "number",
                        "description": "Product's stock quantity"
                      }
                    },
                    "required": [
                      "id",
                      "name",
                      "price",
                      "stock"
                    ]
                  }
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        }
      },
      "post": {
        "summary": "Create a new product",
        "responses": {
          "201": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "id": {
                      "type": "string",
                      "description": "Product's unique ID"
                    },
                    "name": {
                      "type": "string",
                      "description": "Product's name"
                    }
                  },
                  "required": [
                    "id",
                    "name"
                  ]
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        },
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "name": {
                    "type": "string",
                    "description": "Product's name"
                  },
                  "price": {
                    "type": "number",
                    "description": "Product's price"
                  },
                  "stock": {
                    "type": "number",
                    "description": "Product's stock quantity"
                  }
                },
                "required": [
                  "name",
                  "price",
                  "stock"
                ]
              }
            }
          }
        }
      }
    },
    "/api/cart": {
      "get": {
        "summary": "Get user's cart",
        "responses": {
          "200": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "id": {
                      "type": "string",
                      "description": "Cart's unique ID"
                    },
                    "items": {
                      "type": "array",
                      "description": "List of cart items",
                      "items": {
                        "type": "object"
                      }
                    },
                    "user_id": {
                      "type": "string",
                      "description": "User's ID associated with the cart"
                    }
                  },
                  "required": [
                    "id",
                    "items",
                    "user_id"
                  ]
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        }
      },
      "post": {
        "summary": "Add item to cart",
        "responses": {
          "201": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {}
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        },
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "product_id": {
                    "type": "string",
                    "description": "Product's ID to add to cart"
                  },
                  "quantity": {
                    "type": "number",
                    "description": "Quantity of product to add"
                  }
                },
                "required": [
                  "product_id",
                  "quantity"
                ]
              }
            }
          }
        }
      },
      "delete": {
        "summary": "Remove item from cart",
        "responses": {
          "204": {
            "description": "Successful operation"
          },
          "422": {
            "description": "Invalid input"
          }
        },
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "product_id": {
                    "type": "string",
                    "description": "Product's ID to remove from cart"
                  }
                },
                "required": [
                  "product_id"
                ]
              }
            }
          }
        }
      }
    },
    "/api/orders": {
      "post": {
        "summary": "Place an order",
        "responses": {
          "201": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "id": {
                      "type": "string",
                      "description": "Order's unique ID"
                    },
                    "total": {
                      "type": "number",
                      "description": "Total amount of the order"
                    },
                    "payment_status": {
                      "type": "string",
                      "description": "Status of the payment"
                    }
                  },
                  "required": [
                    "id",
                    "total",
                    "payment_status"
                  ]
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        }
      },
      "get": {
        "summary": "Get user's order history",
        "responses": {
          "200": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "array",
                  "items": {
                    "type": "object",
                    "properties": {
                      "id": {
                        "type": "string",
                        "description": "Order's unique ID"
                      },
                      "total": {
                        "type": "number",
                        "description": "Total amount of the order"
                      },
                      "payment_status": {
                        "type": "string",
                        "description": "Status of the payment"
                      }
                    },
                    "required": [
                      "id",
                      "total",
                      "payment_status"
                    ]
                  }
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        }
      }
    },
    "/api/payments": {
      "post": {
        "summary": "Process test-mode payment",
        "responses": {
          "201": {
            "description": "Successful operation",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "id": {
                      "type": "string",
                      "description": "Payment's unique ID"
                    },
                    "order_id": {
                      "type": "string",
                      "description": "Order's ID associated with the payment"
                    },
                    "status": {
                      "type": "string",
                      "description": "Status of the payment"
                    }
                  },
                  "required": [
                    "id",
                    "order_id",
                    "status"
                  ]
                }
              }
            }
          },
          "422": {
            "description": "Invalid input"
          }
        },
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "order_id": {
                    "type": "string",
                    "description": "Order's ID to process payment for"
                  },
                  "amount": {
                    "type": "number",
                    "description": "Amount of the payment"
                  }
                },
                "required": [
                  "order_id",
                  "amount"
                ]
              }
            }
          }
        }
      }
    }
  }
}


## Migration Sql

CREATE TABLE User (
  id UUID PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  cart_id UUID
);

CREATE TABLE Product (
  id UUID PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL
);

CREATE TABLE Cart (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL
);

CREATE TABLE CartItem (
  id UUID PRIMARY KEY,
  product_id UUID NOT NULL,
  quantity INT NOT NULL
);

CREATE TABLE Order (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  payment_status VARCHAR(50) NOT NULL
);

CREATE TABLE OrderItem (
  id UUID PRIMARY KEY,
  product_id UUID NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL
);

ALTER TABLE Cart ADD FOREIGN KEY (user_id) REFERENCES User(id);
ALTER TABLE CartItem ADD FOREIGN KEY (product_id) REFERENCES Product(id);
ALTER TABLE Order ADD FOREIGN KEY (user_id) REFERENCES User(id);
ALTER TABLE OrderItem ADD FOREIGN KEY (product_id) REFERENCES Product(id);


## Performance Notes

- All endpoints require authentication using JWT tokens.

- Ownership checks are enforced in business logic for product management and order operations.

- Password hashing is implemented using bcrypt for secure storage.

- Test-mode payments are clearly labeled and do not process real transactions.

- Indexing is used on email and user_id fields for faster lookups.

- OpenAPI is compiled from model-proposed endpoint fields. Nested array item schemas and authorization contracts need human refinement before client generation.