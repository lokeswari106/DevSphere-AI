## Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/your-username/ecommerce-platform.git
```

### 2. Install Dependencies

```bash
cd ecommerce-platform
pip install -r requirements.txt
```

### 3. Run the Application

```bash
uvicorn app:app --reload
```

### 4. Access the API

Open your browser and navigate to http://localhost:8000/docs to access the API documentation.

### 5. Use the API

- Register a new user by sending a POST request to `/api/users` with the user's email and password.
- Login to the system by sending a POST request to `/api/users/login` with the user's email and password.
- Manage products by sending POST requests to `/api/products` with admin credentials.
- Add/remove items from the cart by sending POST/DELETE requests to `/api/cart` with the user's token.
- Place orders by sending POST requests to `/api/orders` with the user's token.
- Process test payments by sending POST requests to `/api/test-payment` with the user's token and the order ID.