"""Human-reviewed regression tests for the actual API, not a stub implementation."""
import uuid
import pytest
from fastapi.testclient import TestClient
import app as module


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(module, "DB_PATH", str(tmp_path / "shop.db"))
    with TestClient(module.app) as client:
        yield client


def register(client, email="user@example.com"):
    response = client.post("/api/users", json={"email": email, "password": "strong-password"})
    assert response.status_code == 201, response.text
    return response.json()


def login(client, email="user@example.com"):
    response = client.post("/api/users/login", json={"email": email, "password": "strong-password"})
    assert response.status_code == 200, response.text
    return {"Authorization": "Bearer " + response.json()["token"]}


@pytest.fixture
def shopper(client):
    user = register(client)
    return user, login(client)


@pytest.fixture
def admin(client):
    user = register(client, "admin@example.com")
    # A trusted test fixture, never public self-service privilege escalation.
    with module.database() as db:
        db.execute("UPDATE User SET is_admin=1 WHERE id=?", (user["id"],))
    return login(client, "admin@example.com")


@pytest.fixture
def product(client, admin):
    response = client.post("/api/products", headers=admin, json={"name": "Book", "price": 9.99, "stock": 5})
    assert response.status_code == 201, response.text
    return response.json()


def add(client, headers, product, quantity=2):
    response = client.post("/api/cart", headers=headers, json={"product_id": product["id"], "quantity": quantity})
    assert response.status_code == 201, response.text
    return response.json()


def order(client, headers, product):
    cart = add(client, headers, product)
    response = client.post("/api/orders", headers=headers, json={"cart_id": cart["cart_id"]})
    assert response.status_code == 201, response.text
    return response.json()


def test_register_user(client):
    user = register(client)
    assert user["email"] == "user@example.com"
    assert "password_hash" not in user
    with module.database() as db:
        stored = db.execute("SELECT * FROM User WHERE id=?", (user["id"],)).fetchone()
        assert stored["password_hash"] != "strong-password"
        assert module.bcrypt.checkpw(b"strong-password", stored["password_hash"].encode())


@pytest.mark.parametrize("body", [
    {"email": "invalid", "password": "password123"},
    {"email": "ok@example.com", "password": "short"},
    {"email": "ok@example.com", "password": "é" * 40},
    {"email": "ok@example.com", "password": "password123", "is_admin": True},
])
def test_registration_rejects_invalid_input_and_admin_escalation(client, body):
    assert client.post("/api/users", json=body).status_code == 422


def test_duplicate_registration(client):
    register(client)
    assert client.post("/api/users", json={"email": "USER@example.com", "password": "strong-password"}).status_code == 409


def test_login_user(client, shopper):
    assert client.get("/api/cart", headers=shopper[1]).status_code == 200


def test_login_user_invalid_password(client, shopper):
    assert client.post("/api/users/login", json={"email": shopper[0]["email"], "password": "incorrect"}).status_code == 401


def test_invalid_token_is_401_not_server_error(client):
    assert client.get("/api/cart", headers={"Authorization": "Bearer invalid"}).status_code == 401


def test_get_products(client, product):
    assert client.get("/api/products").json() == [product]


def test_create_product_requires_admin(client, shopper):
    assert client.post("/api/products", headers=shopper[1], json={"name":"Book", "price":9.99, "stock":5}).status_code == 403


@pytest.mark.parametrize("price,stock", [(-1,5), (0,5), (10,-1), (10,1.5)])
def test_create_product_invalid_data(client, admin, price, stock):
    assert client.post("/api/products", headers=admin, json={"name":"Book", "price":price, "stock":stock}).status_code == 422


def test_get_cart_and_add_item(client, shopper, product):
    item = add(client, shopper[1], product)
    cart = client.get("/api/cart", headers=shopper[1]).json()
    assert cart["id"] == item["cart_id"]
    assert cart["items"][0]["quantity"] == 2
    assert cart["items"][0]["price"] == 9.99


def test_remove_from_cart(client, shopper, product):
    add(client, shopper[1], product)
    response = client.request("DELETE", "/api/cart", headers=shopper[1], json={"product_id": product["id"], "quantity":2})
    assert response.status_code == 200
    assert client.get("/api/cart", headers=shopper[1]).json()["items"] == []


def test_cart_rejects_invalid_quantity_stock_and_missing_product(client, shopper, product):
    for quantity, status in [(0,422), (-2,422), (6,409)]:
        assert client.post("/api/cart", headers=shopper[1], json={"product_id":product["id"], "quantity":quantity}).status_code == status
    assert client.post("/api/cart", headers=shopper[1], json={"product_id":str(uuid.uuid4()), "quantity":1}).status_code == 404


def test_place_order_and_history(client, shopper, product):
    placed = order(client, shopper[1], product)
    assert placed["total"] == 19.98 and placed["payment_status"] == "pending"
    assert client.get("/api/orders", headers=shopper[1]).json() == [placed]
    assert client.get("/api/cart", headers=shopper[1]).json()["items"] == []
    assert client.get("/api/products").json()[0]["stock"] == 3


def test_checkout_atomic_when_stock_changes(client, shopper, product):
    cart = add(client, shopper[1], product)
    with module.database() as db:
        db.execute("UPDATE Product SET stock=1 WHERE id=?", (product["id"],))
    assert client.post("/api/orders", headers=shopper[1], json={"cart_id":cart["cart_id"]}).status_code == 409
    assert client.get("/api/orders", headers=shopper[1]).json() == []
    assert len(client.get("/api/cart", headers=shopper[1]).json()["items"]) == 1


def test_cannot_access_another_users_cart_or_orders(client, shopper, product):
    cart = add(client, shopper[1], product)
    other = register(client, "other@example.com")
    headers = login(client, other["email"])
    assert client.get("/api/cart", headers=headers, params={"user_id":shopper[0]["id"]}).status_code == 403
    assert client.get("/api/orders", headers=headers, params={"user_id":shopper[0]["id"]}).status_code == 403
    assert client.post("/api/orders", headers=headers, json={"cart_id":cart["cart_id"]}).status_code == 404


def test_checkout_empty_cart(client, shopper):
    cart = client.get("/api/cart", headers=shopper[1]).json()
    assert client.post("/api/orders", headers=shopper[1], json={"cart_id":cart["id"]}).status_code == 400


def test_process_test_payment(client, shopper, product):
    placed = order(client, shopper[1], product)
    body = {"order_id":placed["id"], "payment_status":"success"}
    response = client.post("/api/test-payment", headers=shopper[1], json=body)
    assert response.status_code == 200 and response.json()["test_mode"] is True
    assert response.json()["payment_status"] == "success"
    assert client.post("/api/test-payment", headers=shopper[1], json=body).status_code == 400


def test_payment_rejects_invalid_unknown_and_foreign_orders(client, shopper, product):
    placed = order(client, shopper[1], product)
    register(client,"other@example.com")
    other = login(client,"other@example.com")
    assert client.post("/api/test-payment", headers=other, json={"order_id":placed["id"], "payment_status":"success"}).status_code == 403
    assert client.post("/api/test-payment", headers=shopper[1], json={"order_id":"bad", "payment_status":"success"}).status_code == 400
    assert client.post("/api/test-payment", headers=shopper[1], json={"order_id":str(uuid.uuid4()), "payment_status":"success"}).status_code == 404
    assert client.post("/api/test-payment", headers=shopper[1], json={"order_id":placed["id"], "payment_status":"invented"}).status_code == 422
